import React, { useState, useEffect } from "react";
import { useRouter } from "next/router";
import Link from "next/link";
import Popup from "reactjs-popup";
import ContactForm from "../Contact/ContactForm";

const NavbarTwo = () => {
  // Add active class
  const [currentPath, setCurrentPath] = useState("");
  const router = useRouter();
  const [showModal, setShowModal] = useState(false);
  // console.log(router.asPath)

  useEffect(() => {
    setCurrentPath(router.asPath);
  }, [router]);

  const [menu, setMenu] = React.useState(true);
  const toggleNavbar = () => {
    setMenu(!menu);
  };
  React.useEffect(() => {
    let elementId = document.getElementById("navbar");
    document.addEventListener("scroll", () => {
      if (window.scrollY > 170) {
        elementId.classList.add("is-sticky");
      } else {
        elementId.classList.remove("is-sticky");
      }
    });
  });

  const classOne = menu
    ? "collapse navbar-collapse mean-menu"
    : "collapse navbar-collapse show";
  const classTwo = menu
    ? "navbar-toggler navbar-toggler-right collapsed"
    : "navbar-toggler navbar-toggler-right";

  return (
    <>
      <div id="navbar" className="navbar-area navbar-style-2" style={{backgroundColor:'#1f4462', boxShadow:'none'}}>
        <nav className="navbar navbar-expand-md navbar-light">
          <div className="container">
            <Link href="/" className="navbar-brand">
              <div>
              <img src="/Scroll_White.png" className="black-logo " width='120' height='20' alt="logo" />
              </div>
              <img
                src="/Scroll_White.png" width='120' height='20' 
                className="white-logo"
                alt="logo"
              />
              <p style={{fontSize:10, color:'white', fontWeight:500}}>Performance First</p>
            </Link>

            {/* Toggle navigation */}
            <button
              onClick={toggleNavbar}
              className={classTwo}
              type="button"
              data-toggle="collapse"
              data-target="#navbarSupportedContent"
              aria-controls="navbarSupportedContent"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span className="icon-bar top-bar"></span>
              <span className="icon-bar middle-bar"></span>
              <span className="icon-bar bottom-bar"></span>
            </button>

            <div className={classOne} id="navbarSupportedContent">
              <ul className="navbar-nav">
                <li className="nav-item">
                  <Link
                    href="/"
                    // className={`nav-link ${currentPath == "/" && "active"}`}
                  >
                    Home
                    {/* <i className="fa-solid fa-angle-down"></i> */}
                  </Link>

                  {/* <ul className="dropdown-menu mega-dropdown-menu">
                    <li className="nav-item">
                      <Link
                        href="/"
                        className={`nav-link ${currentPath == "/" && "active"}`}
                      >
                        Default Home
                      </Link>

                      <Link
                        href="/creative-agency/"
                        className={`nav-link ${
                          currentPath == "/creative-agency/" && "active"
                        }`}
                      >
                        Creative Agency
                      </Link>

                      <Link
                        href="/it-agency/"
                        className={`nav-link ${
                          currentPath == "/it-agency/" && "active"
                        }`}
                      >
                        IT Agency
                      </Link>

                      <Link
                        href="/marketing-agency/"
                        className={`nav-link ${
                          currentPath == "/marketing-agency/" && "active"
                        }`}
                      >
                        Marketing Agency
                      </Link>

                      <Link
                        href="/portfolio-agency/"
                        className={`nav-link ${
                          currentPath == "/portfolio-agency/" && "active"
                        }`}
                      >
                        Portfolio Agency
                      </Link>

                      <Link
                        href="/studio-agency/"
                        className={`nav-link ${
                          currentPath == "/studio-agency/" && "active"
                        }`}
                      >
                        Studio Agency
                      </Link>

                      <Link
                        href="/business-agency/"
                        className={`nav-link ${
                          currentPath == "/business-agency/" && "active"
                        }`}
                      >
                        Business Agency
                      </Link>

                      <Link
                        href="/startup-agency/"
                        className={`nav-link ${
                          currentPath == "/startup-agency/" && "active"
                        }`}
                      >
                        Startup Agency
                      </Link>

                      <Link
                        href="/software-startup/"
                        className={`nav-link ${
                          currentPath == "/software-startup/" && "active"
                        }`}
                      >
                        Software Startup <span className="new">New</span>
                      </Link>

                      <Link
                        href="/digital-marketing/"
                        className={`nav-link ${
                          currentPath == "/digital-marketing/" && "active"
                        }`}
                      >
                        Digital Marketing <span className="new">New</span>
                      </Link>

                      <Link
                        href="/business-consulting/"
                        className={`nav-link ${
                          currentPath == "/business-consulting/" && "active"
                        }`}
                      >
                        Business Consulting <span className="new">New</span>
                      </Link>

                      <Link
                        href="/freelancer-portfolio/"
                        className={`nav-link ${
                          currentPath == "/freelancer-portfolio/" && "active"
                        }`}
                      >
                        Freelancer Portfolio <span className="new">New</span>
                      </Link>
                    </li>

                    <li className="nav-item">
                      <Link
                        href="/default-home-2/"
                        className={`nav-link ${
                          currentPath == "/default-home-2/" && "active"
                        }`}
                      >
                        Default Home Two
                      </Link>

                      <Link
                        href="/creative-agency-2/"
                        className={`nav-link ${
                          currentPath == "/creative-agency-2/" && "active"
                        }`}
                      >
                        Creative Agency Two
                      </Link>

                      <Link
                        href="/it-agency-2/"
                        className={`nav-link ${
                          currentPath == "/it-agency-2/" && "active"
                        }`}
                      >
                        IT Agency Two
                      </Link>

                      <Link
                        href="/marketing-agency-2/"
                        className={`nav-link ${
                          currentPath == "/marketing-agency-2/" && "active"
                        }`}
                      >
                        Marketing Agency Two
                      </Link>

                      <Link
                        href="/portfolio-agency-2/"
                        className={`nav-link ${
                          currentPath == "/portfolio-agency-2/" && "active"
                        }`}
                      >
                        Portfolio Agency Two
                      </Link>

                      <Link
                        href="/studio-agency-2/"
                        className={`nav-link ${
                          currentPath == "/studio-agency-2/" && "active"
                        }`}
                      >
                        Studio Agency Two
                      </Link>

                      <Link
                        href="/business-agency-2/"
                        className={`nav-link ${
                          currentPath == "/business-agency-2/" && "active"
                        }`}
                      >
                        Business Agency Two
                      </Link>

                      <Link
                        href="/startup-agency-2/"
                        className={`nav-link ${
                          currentPath == "/startup-agency-2/" && "active"
                        }`}
                      >
                        Startup Agency Two
                      </Link>

                      <Link
                        href="/app-showcase/"
                        className={`nav-link ${
                          currentPath == "/app-showcase/" && "active"
                        }`}
                      >
                        App Showcase <span className="new">New</span>
                      </Link>

                      <Link
                        href="/personal-portfolio/"
                        className={`nav-link ${
                          currentPath == "/personal-portfolio/" && "active"
                        }`}
                      >
                        Personal Portfolio <span className="new">New</span>
                      </Link>

                      <Link
                        href="/saas-startup/"
                        className={`nav-link ${
                          currentPath == "/saas-startup/" && "active"
                        }`}
                      >
                        SaaS Startup <span className="new">New</span>
                      </Link>

                      <Link
                        href="/cyber-security-agency/"
                        className={`nav-link ${
                          currentPath == "/cyber-security-agency/" && "active"
                        }`}
                      >
                        Cyber Security Agency <span className="new">New</span>
                      </Link>
                    </li>
                  </ul> */}
                </li>

                <li className="nav-item">
                  <Link
                    href="/services/"
                    className={`nav-link ${
                      currentPath == "/services/" && "active"
                    }`}
                    onClick={(e) => {
                      e.preventDefault();
                      document
                        .getElementById("services")
                        .scrollIntoView({ behavior: "smooth" });
                    }}
                  >
                    Services
                    {/* <i className="fa-solid fa-angle-down"></i> */}
                  </Link>

                  {/* <ul className="dropdown-menu">
                    <li className="nav-item">
                      <Link
                        href="/services/"
                        className={`nav-link ${
                          currentPath == "/services/" && "active"
                        }`}
                      >
                        Services Style 1
                      </Link>
                    </li>

                    <li className="nav-item">
                      <Link
                        href="/services-2/"
                        className={`nav-link ${
                          currentPath == "/services-2/" && "active"
                        }`}
                      >
                        Services Style 2
                      </Link>
                    </li>

                    <li className="nav-item">
                      <Link
                        href="/services-3/"
                        className={`nav-link ${
                          currentPath == "/services-3/" && "active"
                        }`}
                      >
                        Services Style 3
                      </Link>
                    </li>

                    <li className="nav-item">
                      <Link
                        href="/services-4/"
                        className={`nav-link ${
                          currentPath == "/services-4/" && "active"
                        }`}
                      >
                        Services Style 4
                      </Link>
                    </li>

                    <li className="nav-item">
                      <Link
                        href="/service-details/"
                        className={`nav-link ${
                          currentPath == "/service-details/" && "active"
                        }`}
                      >
                        Service Details
                      </Link>
                    </li>
                  </ul> */}
                </li>

                <li className="nav-item">
                  <Link style={{textTransform:'initial'}}
                    href="/about/"
                    className={`nav-link ${
                      currentPath == "/about/" && "active"
                    }`}
                    onClick={(e) => {
                      e.preventDefault();
                      document
                        .getElementById("aboutus")
                        .scrollIntoView({ behavior: "smooth" });
                    }}
                  >
                    Who we are
                  </Link>
                </li>

                

                  {/* <ul className="dropdown-menu">
                    <li className="nav-item">
                      <Link
                        href="/portfolio/"
                        className={`nav-link ${
                          currentPath == "/portfolio/" && "active"
                        }`}
                      >
                        Portfolio
                      </Link>
                    </li>

                    <li className="nav-item">
                      <Link
                        href="/portfolio-details/"
                        className={`nav-link ${
                          currentPath == "/portfolio-details/" && "active"
                        }`}
                      >
                        Portfolio Details
                      </Link>
                    </li>

                    <li className="nav-item">
                      <Link
                        href="/portfolio-details-2/"
                        className={`nav-link ${
                          currentPath == "/portfolio-details-2/" && "active"
                        }`}
                      >
                        Portfolio Details 2
                      </Link>
                    </li>
                  </ul> */}
              

                {/* <li className="nav-item">
                  <Link
                    href="#"
                    className="nav-link"
                    onClick={(e) => e.preventDefault()}
                  >
                    Pages <i className="fa-solid fa-angle-down"></i>
                  </Link>

                  <ul className="dropdown-menu">
                    <li className="nav-item">
                      <Link
                        href="/about/"
                        className={`nav-link ${
                          currentPath == "/about/" && "active"
                        }`}
                      >
                        About
                      </Link>
                    </li>

                    <li className="nav-item">
                      <Link
                        href="/services/"
                        className={`nav-link ${
                          currentPath == "/services/" && "active"
                        }`}
                      >
                        Services
                      </Link>
                    </li>

                    <li className="nav-item">
                      <Link
                        href="/service-details/"
                        className={`nav-link ${
                          currentPath == "/service-details/" && "active"
                        }`}
                      >
                        Services Details
                      </Link>
                    </li>

                    <li className="nav-item">
                      <Link
                        href="/portfolio/"
                        className={`nav-link ${
                          currentPath == "/portfolio/" && "active"
                        }`}
                      >
                        Portfolio
                      </Link>
                    </li>

                    <li className="nav-item">
                      <Link
                        href="/portfolio-details/"
                        className={`nav-link ${
                          currentPath == "/portfolio-details/" && "active"
                        }`}
                      >
                        Portfolio Details
                      </Link>
                    </li>

                    <li className="nav-item">
                      <Link
                        href="/team/"
                        className={`nav-link ${
                          currentPath == "/team/" && "active"
                        }`}
                      >
                        Team
                      </Link>
                    </li>

                    <li className="nav-item">
                      <Link
                        href="/pricing/"
                        className={`nav-link ${
                          currentPath == "/pricing/" && "active"
                        }`}
                      >
                        Pricing
                      </Link>
                    </li>

                    <li className="nav-item">
                      <Link
                        href="/faq/"
                        className={`nav-link ${
                          currentPath == "/faq/" && "active"
                        }`}
                      >
                        FAQ
                      </Link>
                    </li>

                    <li className="nav-item">
                      <Link
                        href="/404/"
                        className={`nav-link ${
                          currentPath == "/404/" && "active"
                        }`}
                      >
                        404 error
                      </Link>
                    </li>

                    <li className="nav-item">
                      <Link
                        href="/coming-soon/"
                        className={`nav-link ${
                          currentPath == "/coming-soon/" && "active"
                        }`}
                      >
                        Coming Soon
                      </Link>
                    </li>

                    <li className="nav-item">
                      <Link
                        href="/contact/"
                        className={`nav-link ${
                          currentPath == "/contact/" && "active"
                        }`}
                      >
                        Contact
                      </Link>
                    </li>
                  </ul>
                </li> */}

                <li className="nav-item">
                  <Link
                    href=""
                    className={`nav-link ${
                      currentPath == "/blog/" && "active"
                    }`}
                    onClick={(e) => {
                      e.preventDefault();
                      document
                        .getElementById("blogs")
                        .scrollIntoView({ behavior: "smooth" });
                    }}
                  >
                    Work
                    {/* <i className="fa-solid fa-angle-down"></i> */}
                  </Link>

                  {/* <ul className="dropdown-menu">
                    <li className="nav-item">
                      <Link
                        href="/blog/"
                        className={`nav-link ${
                          currentPath == "/blog/" && "active"
                        }`}
                      >
                        Blog Grid
                      </Link>
                    </li>

                    <li className="nav-item">
                      <Link
                        href="/blog2/"
                        className={`nav-link ${
                          currentPath == "/blog2/" && "active"
                        }`}
                      >
                        Blog Right Sidebar
                      </Link>
                    </li>

                    <li className="nav-item">
                      <Link
                        href="/blog3/"
                        className={`nav-link ${
                          currentPath == "/blog3/" && "active"
                        }`}
                      >
                        Blog Left Sidebar
                      </Link>
                    </li>

                    <li className="nav-item">
                      <Link
                        href="/blog-details/"
                        className={`nav-link ${
                          currentPath == "/blog-details/" && "active"
                        }`}
                      >
                        Blog Details
                      </Link>
                    </li>
                  </ul> */}
                </li>

                {/* <li className="nav-item">
                  <Link
                    href="/contact/"
                    className={`nav-link ${
                      currentPath == "/contact/" && "active"
                    }`}
                  >
                    Contact Us
                  </Link>
                </li> */}
              </ul>

              <div className="others-options">
                <Link
                 onClick={() => {
                  setShowModal(true)
                }}
                href="#" className="btn"  style={{color:"white", backgroundColor:'transparent',border:'1px solid white', AnimationEffect:'none'}}>
                  Let's talk
                </Link>
              </div>
            </div>
          </div>
        </nav>
        <Popup
            open={showModal}
            onClose={() => {
              setShowModal(false);
            }}
            contentStyle={{
              borderRadius: "10px",
              minHeight: "55%",
              minWidth: "90%",
              overflow:"scroll",
              maxHeight:"95%"
            }}
            position="right center"
          >
            <div
              style={{
                paddingTop: "20px",
                paddingBottom: "20px",
                borderRadius: 10,
              }}
            >
              <div 
              onClick={()=>{
                setShowModal(false);
              }}
              style={{
                position:"absolute",
                right:"10px",
                top:"10px",
                fontSize:"20px",
                cursor:"pointer"
              }}>
               &#10006;
              </div>
              
              <div style={{
            
              }}><ContactForm/></div>
            </div>
          </Popup>
      </div>
    </>
  );
};

export default NavbarTwo;
